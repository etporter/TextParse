from distutils.core import setup
setup(name='textParse',
      version='1.0',
      py_modules=['textParse'],
      )