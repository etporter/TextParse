Copyright 2014 Ethan Porter
textParse module - version 1.0

This module includes both a constructor for a textParse object and static
methods.

Use the constructor for a specific, repeated use of this class.

Otherwise, you can use the static methods to parse your text.

Ethan Porter
etporter2010@gmail.com